SELECT DISTINCT name
FROM authors
WHERE conference in (SELECT conference
		     FROM conferences
		     WHERE area='systems')
GROUP BY name
HAVING SUM(count) > 1
EXCEPT
SELECT DISTINCT name
FROM authors
WHERE conference in (SELECT conference
		     FROM conferences
		     WHERE area='systems')
GROUP BY name
HAVING MAX(year) < 2014
ORDER BY name;
