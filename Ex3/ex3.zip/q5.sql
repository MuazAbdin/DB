WITH NotSpecConfs(conference) AS
	 (SELECT conference
	  FROM authors
	  GROUP BY conference
	  HAVING COUNT(DISTINCT year) < 10)
SELECT DISTINCT name
FROM authors
EXCEPT
SELECT DISTINCT name
FROM authors
WHERE conference IN (SELECT * FROM NotSpecConfs)
ORDER BY name;
