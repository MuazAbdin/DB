WITH PaperCounts(region, country, totalCount) as
	 (SELECT region, country, SUM(count) + 0.0
	  FROM institutions NATURAL JOIN authors 
	  GROUP BY region, country)
SELECT P1.region, P1.country, P1.totalCount
FROM PaperCounts P1
WHERE P1.totalCount >= all (SELECT P2.totalCount
			 				FROM PaperCounts P2
							WHERE P1.region = P2.region)
ORDER BY region, country;
