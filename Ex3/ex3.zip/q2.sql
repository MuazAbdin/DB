SELECT region, COUNT(DISTINCT institution) * 1.0 / COUNT(DISTINCT country) AS insAvg
FROM institutions
GROUP BY region
ORDER BY region;
