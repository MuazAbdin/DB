WITH RECURSIVE T(name, dist) AS (
		VALUES('Noam Nisan', 0)
		UNION
		SELECT second, dist + 1
		FROM T INNER JOIN (SELECT A1.name AS first, A2.name AS second
						     FROM authors A1 INNER JOIN authors A2
  							   ON (A1.name != A2.name and
							       A1.conference = A2.conference and
							  	   A1.year = A2.year)) D
		  ON (T.name = D.first)
		WHERE dist < 2
)
SELECT DISTINCT name FROM T ORDER BY name;
