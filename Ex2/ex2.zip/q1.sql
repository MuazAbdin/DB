select distinct name
from authors
where institution = 'Hebrew University of Jerusalem'
order by name;
