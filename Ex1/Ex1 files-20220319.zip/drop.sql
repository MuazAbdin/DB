drop table oscars;
